**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WBAxx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  
  These packages contains the needed files to be installed in order to support STM32WBAxx
  devices by MDK-ARM v5.25 and laters.

  Running the "Keil.STM32WBAxx_DFP.1.3.0.pack" adds the following:
  ===================================================================
   - Product Number with 1MB Flash size: STM32WBA50xGxx/STM32WBA52xGxx/STM32WBA54xGxx/STM32WBA55xGxx.
   - Product Number with 512kB Flash size: STM32WBA50xExx/STM32WBA52xExx/STM32WBA54xExx/STM32WBA55xExx
   - Automatic STM32WBAxx internal flash algorithm selection   
   - STM32XWBA52 SVD file  


  How to use:
  ==========
  * Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
  You can download pack from keil web site @ www.keil.com
 
  * Double Clic on  "Keil.STM32WBAxx_DFP.1.3.0.pack" in order to install this pack in the Keil install 
  directory.


